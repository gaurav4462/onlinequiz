<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .main{
            width: 1000px;
            height: 370px;
            border: 5px solid #cbcbcb;
            padding-left: 50px;


        }

        a {
          text-decoration: none;
          display: inline-block;
          padding: 8px 16px;
        }

        a:hover {
          background-color: #ddd;
          color: black;
        }

        .previous {
          background-color: #f1f1f1;
          color: black;
        }

        .next {
          background-color: #f1f1f1;
          color: black;
        }
        .save {
          background-color: #04AA6D;
          color: white;
        }

        .round {
          border-radius: 50%;
        }
    </style>


        
    
  </head>
  <body class="p-3 m-0 border-0 bd-example">


    <?php

        $server = "localhost";
        $username = "root";
        $password = "gaurav";
        $database = "users";

        $conn = mysqli_connect($server, $username, $password, $database);
        if (!$conn){
        
            die("Error". mysqli_connect_error());
        }
    ?>
    <?php 
      session_start();
      $key1 = $_SESSION['key']-- ;
      $_SESSION['count']-- ;
    ?>


    


    

    <?php
        $key1 = $key1-1;
        if($_SESSION['count']==0){
          $_SESSION['count']++;
          $key1++;
          
          $_SESSION["key"]++;
        }

        $_SESSION['value'] = $key1;
        




        $sql = "SELECT * FROM `questions` Where queid=$key1";
        $result = mysqli_query($conn, $sql);



        $num = mysqli_num_rows($result);
        $row = mysqli_fetch_assoc($result);
    
    ?>

            <div class="main">

            <?php echo " $_SESSION[count] $row[question] ";?><br>
                    
              <form action="code.php" method="POST">
                    
                  <div>
                      <input type="radio" name="ans" value="a" /> <?php echo "1 $row[op1]" ?><br>
                      <input type="radio" name="ans" value="b" /> <?php echo "2 $row[op2]" ?><br>
                      <input type="radio" name="ans" value="c" /> <?php echo "3 $row[op3]" ?><br>
                      <input type="radio" name="ans" value="c" /> <?php echo "4 $row[op4]" ?><br>
                  </div>
                  <div class="d-grid gap-5 col-2 mx-auto">
                    <a href="Previous.php" class="previous">&laquo; Previous</a>
                    <a href="next.php" class="next">Next &raquo;</a>
                    <button name="save_radio" class="save">Save</button>
                </div>
              </form>
            </div>

        


            


    
            
  </body>
</html>








   



