<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>

        /* .div1{
            margin-left: 100px;
            width: 120px;
            height: 80px;
            border: 5px solid #cbcbcb;

        }
        .div2{
            margin-left: 500px;
            width: 120px;
            height: 80px;
            border: 5px solid #cbcbcb;

        }
        .div1, .div2
        {
            display: flow-root;
        } */

        /* .question {
          background-color: #04AA6D;  */
          /* display: flex;
          color: white;
        } */

        .div1{
          margin-left: 120px;
          float: left;

          padding: 15px;

          border: 5px solid #cbcbcb;
          width: 120px;
          height: 80px;
        }
        .div3{
          margin-left: 150px;
          margin-top: 30px;
          float: left;



          border: 5px solid #cbcbcb;
          /* background-color: #04AA6D;  */
          color: white;
          width: 70px;
          height: 55px;
        }
        .div5{
          margin-left: 200px;
          margin-top: 40px;
          float: left;


          border: 5px solid #cbcbcb;
          width: 100px;
          height: 35px;
        }
        .div6{
          margin-left: 200px;
          margin-top: 50px;
          float: left;



          border: 5px solid #cbcbcb;
          width: 32px;
          height: 17px;
        }

        

        .div2:after {
          content: "";
          display: table;
          clear: both;
        }
        
    </style>

    
</head>
<body>

    <?php
    $server = "localhost";
    $username = "root";
    $password = "gaurav";
    $database = "users";
    
    $conn = mysqli_connect($server, $username, $password, $database);
    if (!$conn){
    
        die("Error". mysqli_connect_error());
    }
    
    ?>

    <?php

    $sql = "SELECT *
    FROM data1
    WHERE rid = 'a' or rid = 'b' or rid = 'c' or rid = 'd';";
    $result = mysqli_query($conn, $sql);
    
    
    
    $num = mysqli_num_rows($result);
    

    $sql1 = "SELECT *
    FROM data1
    WHERE rid is NOT NULL";
    $result1 = mysqli_query($conn, $sql1);
    
    
    
    $num1 = mysqli_num_rows($result1);
    
    ?>



    <div class="div2">
    <div class="div1">
        &nbsp No Of Question <br> <br>
        &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp <?php echo "$num1" ?>
    </div>

    <div class="div1">
        &nbsp total attepted <br> <br>
        &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp <?php echo "$num" ?>
    </div>

    <?php
    $x =  ($num/$num1)*100 
    ?>
    

    <div class="div1">
        &nbsp &nbsp &nbsp accuricy <br> <br>
        &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp <?php echo "$x" ?>
    </div>
    </div>
    <div class="div4">
    <div class="div3" >
        <a href="download question.php" type="submit" name="question" class="question">Download Question Paper
    </div>
    <div class="div5" >
        <a href="download answer.php" type="submit" name="question" class="question">Download Answer Key
    </div>
    <div class="div6" >
        <a  href="#" type="submit"  name="question" class="question">Next
    </div>
    </div>
    


</body>
</html>