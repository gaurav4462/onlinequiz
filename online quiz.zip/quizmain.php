<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .button1 {
        background-color: white;
        border: 2px solid black;
        color: green;
        padding: 5px 10px;
        text-align: center;
        display: inline-block;
        font-size: 20px;
        margin: 10px 30px;
        cursor: pointer;
        margin-left: 40%;
        }

        .main{
            margin-left: 250px;
            width: 509px;
            height: 400px;
            border: 5px solid #cbcbcb;

        }
        
    </style>

</head>
<body>
    <div class= "main">
        <img src="online quiz.jpg">
        <form action="next.php">
        <button class = "button1" type="submit">
            Start Quiz
        </button>
    </form>
    <?php
       

        session_start();
        $_SESSION['key'] = rand(1,10);
        $_SESSION['count'] = 0;


    ?>


    <?php
        $server = "localhost";
        $username = "root";
        $password = "gaurav";
        $database = "users";

        $conn = mysqli_connect($server, $username, $password, $database);
        if (!$conn){

            die("Error". mysqli_connect_error());
        }



        $sql = "DROP TABLE IF EXISTS data1 ";
        $result = mysqli_query($conn, $sql);





        $sql = "CREATE TABLE data1 (
            qid VARCHAR(10) NOT NULL,
            aid VARCHAR(10) NOT NULL,
            rid VARCHAR(10) 
        )";
        $result = mysqli_query($conn, $sql);
        if ($result){
            $showAlert = true;
        }
        else{
            $showError = "Passwords do not match";
        }



    ?>


    </div>
</body>
</html>